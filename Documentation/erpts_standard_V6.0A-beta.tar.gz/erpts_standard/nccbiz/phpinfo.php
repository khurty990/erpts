<!doctype html public "-//W3C//DTD HTML 4.0 //EN">
<html>
<head>
       <title>Test Page using PHPInfo</title>
</head>
<body>
<?php
     phpinfo();
?>
</body>
</html>
