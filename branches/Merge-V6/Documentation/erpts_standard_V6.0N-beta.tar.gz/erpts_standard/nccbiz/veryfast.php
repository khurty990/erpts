<!doctype html public "-//W3C//DTD HTML 4.0 //EN">
<html>
<head>
       <title>Test Page for Benchmarking Response Time</title>
</head>
<body>
<?php
     echo "this is a very fast page";
?>
</body>
</html>
