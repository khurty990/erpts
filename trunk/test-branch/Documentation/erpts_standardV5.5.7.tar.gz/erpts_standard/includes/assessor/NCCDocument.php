
/**
 * The NCCDocument Class is a parent class to all the actual documents found within the system
 */
class NCCDocument{
	/**
	 * TheNCC Document() Constructor
         */
	NCCDocument(){
	}
	/**
         * The printDoc() function sends the document information to the printer
         */
	printDoc(){
	}
}
