<?php
## Author: Reuben J. Ravago
##         K2 Inter[a]ctive, Inc.

## send a soap request to biz server
## parameters tdArray, dueDate
## response dueArray

class GetDues {
}
new GetDues();

?>
